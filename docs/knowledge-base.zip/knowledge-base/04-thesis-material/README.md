# Thesis Material

This section maps the knowledge base to the BITS Pilani M.Tech dissertation by student 2024MT03053 on the topic of a privacy-first AI guardrail engine.

## How to Use This Section

The dissertation (`docs/university/2024mt03053.md`) was written against the **pre-rewrite** 4-inspector architecture. The production system described in this knowledge base is the post-rewrite implementation, which differs substantially. This README tracks where the two align and where the dissertation's framing must be updated to reflect the current system.

## Pre-Rewrite vs. Post-Rewrite Architecture

| Dimension       | Dissertation (pre-rewrite)          | Current system (post-rewrite)                                                                                                        |
| --------------- | ----------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------ |
| Inspector count | 4 (NER, Regex, Semantic, Jailbreak) | 7+ (Presidio NER, Regex injection, Semantic content, SQL injection, Shell injection, Jailbreak detector, ConversationTurn deception) |
| Pipeline stages | ~5 stages (implicit)                | 12 explicit `STAGE_*` constants with `stage_runner` instrumentation                                                                  |
| Extension model | ABC inheritance                     | PEP 544 structural `Protocol` — no import required                                                                                   |
| Observability   | Log-based                           | Four independent surfaces: Logger, Tracer, MetricSink, LifecycleSink (29 typed events)                                               |
| Storage         | Not addressed                       | SQLite lifecycle sink with schema v2; WAL mode; 4 tables                                                                             |
| Rehydration     | Not addressed                       | FidelityScorer + RehydrationVerifier (IntentLock → placeholder map → fidelity-gated rehydration)                                     |
| Deployment      | Library                             | Three-package workspace: `arc-guard-core`, `arc-guard`, `arc-guard-service`                                                          |

## Chapter-to-KB Mapping

| Dissertation chapter                               | Relevant KB documents                                                                |
| -------------------------------------------------- | ------------------------------------------------------------------------------------ |
| Problem statement: LLM privacy risks in enterprise | `00-overview.md` — problem table, design principles                                  |
| System architecture overview                       | `01-architecture/guardrail-pipeline.md`, `01-architecture/package-structure.md`      |
| Detection subsystem                                | `01-architecture/inspection-subsystem.md`                                            |
| Sanitization and rehydration                       | `01-architecture/strategy-subsystem.md`, `02-data-flows/pii-redaction-flow.md`       |
| Threat model: prompt injection                     | `02-data-flows/prompt-injection-flow.md`                                             |
| Observability and audit                            | `01-architecture/observability.md`, `01-architecture/lifecycle-sink.md`              |
| API and integration                                | `01-architecture/api-service.md`                                                     |
| Architectural decisions                            | `03-decisions/protocol-over-inheritance.md`, `03-decisions/sqlite-lifecycle-sink.md` |

## What the Dissertation Got Right

- The core threat model: LLM systems processing enterprise data face PII exfiltration, prompt injection, and jailbreak risks that require an in-process interception layer
- The principle of processing in-process (zero network hops for the core detection path) — confirmed by the P99 < 25ms lite-mode latency target
- Inspector independence: findings from different inspectors are additive, not chained — the rewrite preserved this property

## What Changed

- The rewrite replaced the ABC-based inspector hierarchy with PEP 544 Protocols — see `03-decisions/protocol-over-inheritance.md`
- `ConversationState` / deception inspection was not in scope for the dissertation; it is now a first-class pipeline stage
- The `IntentLock` → `FidelityScorer` → `RehydrationVerifier` chain is new; the dissertation described placeholder-based redaction but not the semantic fidelity gate on rehydration
- The 12-stage `stage_runner` instrumentation model is new; the dissertation used ad-hoc logging

## Notes for Thesis Revision

When updating the dissertation to reflect the post-rewrite system:

1. Replace all references to `BaseInspector` ABC with the Protocol model
2. Update the architecture diagram to show the 12-stage pipeline
3. Add the `LifecycleSink` as the audit surface (29 typed events → SQLite)
4. Update inspector count and names (Presidio replaces the generic NER description)
5. Add the fidelity-gated rehydration flow as a new subsection
6. The `docs/canvases/` visual canvases provide up-to-date architecture diagrams suitable for inclusion
