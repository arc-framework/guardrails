# GuardPipeline — 12-Stage Architecture

## Overview

The `GuardPipeline` executes every guard request through exactly 12 named stages, each wrapped by `stage_runner` for uniform span/event/metric emission. The stage constants are the authoritative closed set defined in `packages/core/src/arc_guard_core/stages.py`.

Stage names are `Final[str]` constants (not `StrEnum`) so the set remains open to additive extension across specs without breaking existing call sites.

## The 12 Stages

```mermaid
flowchart LR
  V[1·validate] --> D[2·defend] --> C[3·classify] --> DI[4·deception_inspect]
  DI --> S[5·sanitize] --> R[6·route]
  R -->|CRITICAL risk| RF[8·refusal]
  R -->|pass/warn/redact| E[7·execute]
  E --> RF & VR[9·verify]
  VR --> RH[10·rehydrate]
  RF & RH --> DE[11·decision_emit] --> RP[12·report]
```

### 1. `STAGE_VALIDATE` — `"validate"`

Schema validation and boundary checks on the incoming `GuardInput`. Rejects malformed payload shapes, invalid thresholds, unknown rule references, and cross-field config errors before any detection or model call runs.

`_validate_finding()` and `_validate_decision()` from `packages/core/src/arc_guard_core/pipeline.py` enforce span sanity (`start >= 0`, `end > start`), score range (`0.0–1.0`), non-empty inspector name, and valid `RiskLevel` enum membership.

### 2. `STAGE_DEFEND` — `"defend"`

Captures the information needed for intent preservation and adversarial safety checks. The `IntentEncoder` Protocol (optional extra `[semantic]`) encodes the original prompt into a semantic representation stored in the `IntentLock` (`packages/core/src/arc_guard_core/intent_lock.py`). This representation is used later by `STAGE_VERIFY` to measure answer drift.

Skipped when no `IntentEncoder` is configured — the stage runs but is a no-op pass.

### 3. `STAGE_CLASSIFY` — `"classify"`

The detection layer. All registered `Inspector` implementations run against the input and emit `Finding` objects. Inspectors are independent — a failure in one does not block others (fail-open posture per spec 004).

Concrete inspectors shipped in `packages/pip/src/arc_guard/inspectors/`:

- Regex prompt injection (pattern matching)
- Presidio NER (PII/PCI entity recognition via Microsoft Presidio)
- Semantic classifier (DistilBERT-backed, `[semantic]` extra)
- Custom entity registry (hot-reloadable)
- SQL injection: `_detect_stacked`, `_detect_union`, `_detect_comment_terminator` (`inspectors/code_injection/sql.py`)
- Shell injection: `_scan`, `_looks_like_shell_command`, `_matching_close` (`inspectors/code_injection/shell.py`)
- Jailbreak signals: `detect`, `_scan` (`jailbreak/detector.py`) — produces `Finding` objects with jailbreak category as `entity_type`

Each `Finding` carries: `inspector` name, `entity_type`, `start`/`end` span, `risk_level` (`RiskLevel` enum), optional `score`, and optional `metadata`.

### 4. `STAGE_DECEPTION_INSPECT` — `"deception_inspect"`

Multi-turn deception tracking. Reads and updates `ConversationState` to detect gradual policy erosion, role-play coercion, hypothetical framing, and slow-escalation patterns across turns. The `ConversationTurnInspector` Protocol is the extension point.

Output feeds into policy routing as an additional signal — not a second isolated guard path.

Skipped when no `ConversationState` is provided in the `GuardInput`.

### 5. `STAGE_SANITIZE` — `"sanitize"`

Transforms detected sensitive spans into **typed placeholders** (`[CUSTOMER_NAME]`, `[CREDIT_CARD_2]`) or other configured forms. The numbering scheme preserves repeated-entity structure. The `PlaceholderMapBuilt` lifecycle event fires here.

Sanitization is policy-driven: a `ContentPolicy` (`packages/pip/src/arc_guard/inspectors/`) decides which findings get sanitized vs. passed through for other strategies.

The `SanitizationApplied` lifecycle event carries the before/after text under `text_after` when `lifecycle_capture_payloads=True` (off by default).

### 6. `STAGE_ROUTE` — `"route"`

The `PolicyRouter` evaluates the complete finding set and emits `PolicyDecision` objects — one per finding or group. Risk bands determine the outcome:

| Band       | Behavior                                                  |
| ---------- | --------------------------------------------------------- |
| `LOW`      | Sanitize and continue                                     |
| `MEDIUM`   | Sanitize and warn                                         |
| `HIGH`     | Partial refusal with sanitized output + `RefusalEnvelope` |
| `CRITICAL` | Hard block — no released text, only `RefusalEnvelope`     |

`PolicyRuleEvaluated` and `PolicyResolved` lifecycle events fire here.

### 7. `STAGE_EXECUTE` — `"execute"`

Sends the sanitized prompt to the downstream LLM or backend. Raw sensitive content never leaves the trusted boundary — the transport sees only the transformed prompt. `BackendCalled` and `BackendResponded` lifecycle events bracket the call.

`StrategyExecuted` events fire for each applied `ActionStrategy`.

### 8. `STAGE_REFUSAL` — `"refusal"`

Constructs the `RefusalEnvelope` when the policy outcome is `CRITICAL` or `HIGH`. Returns a machine-readable structured explanation (what triggered the refusal, which policy fired, what the caller should do next). `RefusalProduced` lifecycle event fires here.

Added as an explicit stage so refusal behavior has its own span/metric without being conflated with `STAGE_ROUTE`.

### 9. `STAGE_VERIFY` — `"verify"`

After generation, the `FidelityScorer` measures whether the LLM answer still aligns with the captured `IntentLock`. The fidelity ladder:

- High fidelity → continue
- Moderate drift → warn
- Stronger drift → `ClarificationRequest`
- Unacceptable drift → refuse

Risk posture overrides fidelity: a `CRITICAL` block from routing cannot be un-blocked by a high fidelity score.

`RehydrationVerified` lifecycle event fires at the end of this stage.

### 10. `STAGE_REHYDRATE` — `"rehydrate"`

The `RehydrationVerifier` checks that reinserting original values is structurally and semantically safe — every placeholder maps to a known entity, surrounding structure is preserved, and rehydration doesn't reconstruct an attack path. Only then does the system return the fully rehydrated answer.

Supports partial rehydration (some placeholders kept) when full rehydration fails verification.

### 11. `STAGE_DECISION_EMIT` — `"decision_emit"`

Assembles and emits the `DecisionRecord` — the audit object binding findings, policy decisions, outcome, and intent lock **without** storing raw payload text. The `DecisionEmitted` lifecycle event fires. The `decision_record_recorder` (`packages/pip/src/arc_guard/observability/`) writes this to the SQLite `decision_records` table.

### 12. `STAGE_REPORT` — `"report"`

Non-authoritative side-channel emission: stage events, metrics, traces, and `Reporter` outputs flow through configured hooks. Reporter failure never changes the request outcome. `RequestCompleted` is the final lifecycle event.

## stage_runner Hooks

Every stage is wrapped by `stage_runner` which uniformly emits:

- `StageRan` lifecycle event (stage name, duration_ms, outcome)
- OTEL span (via `Tracer` Protocol)
- Structured log entry (via `Logger` Protocol)
- Histogram metric (via `MetricSink` Protocol + OTEL middleware at `packages/pip/src/arc_guard/middleware/otel/__init__.py`)

This means every stage gets identical observability with zero per-stage boilerplate.

## Extension Points by Stage

| Stage                   | Extension Protocol                                  |
| ----------------------- | --------------------------------------------------- |
| `classify` (3)          | `Inspector`                                         |
| `deception_inspect` (4) | `ConversationTurnInspector`                         |
| `route` (6)             | `PolicyRouter`, `ContentPolicy`, `StrategySelector` |
| `execute` (7)           | `ActionStrategy`                                    |
| `verify` (9)            | `IntentEncoder`, `FidelityScorer`                   |
| `rehydrate` (10)        | `RehydrationVerifier`                               |
| `report` (12)           | `Reporter`, `JailbreakDetector`                     |
| All stages              | `LifecycleSink` (4th observability surface)         |
