# Observability

## Four Independent Surfaces

arc-guardrails ships four independent observability surfaces. Each is a Protocol — operators can implement any or all:

| Surface         | Protocol        | Default             | What it captures                                                                           |
| --------------- | --------------- | ------------------- | ------------------------------------------------------------------------------------------ |
| `Logger`        | `Logger`        | `NullLogger`        | Structured event per stage: name, level, fields, timestamp                                 |
| `Tracer`        | `Tracer`        | `NullTracer`        | OTEL-compatible spans: name, attrs, start/end, duration_ms                                 |
| `MetricSink`    | `MetricSink`    | `NullMetricSink`    | Histograms and counters: latency, finding counts, strategy outcomes                        |
| `LifecycleSink` | `LifecycleSink` | `NullLifecycleSink` | 29 typed, parent-id-linked events per request (see [lifecycle-sink.md](lifecycle-sink.md)) |

These four surfaces are **sibling protocols** — they coexist, fail independently, and never replace each other. A `LifecycleSink` failure doesn't affect `Logger` output. This is verified by `test_lifecycle_does_not_change_existing_events.py`.

## The stage_runner Emission Pattern

Every stage is wrapped by `stage_runner`, which emits uniformly before and after the stage body:

1. **Before:** record start timestamp, begin OTEL span
2. **Stage body executes**
3. **After:** emit `StageRan` lifecycle event (stage name, `duration_ms`, outcome), close span, emit `Logger` event, increment `MetricSink` histogram

This pattern means zero per-stage observability boilerplate. Adding a new stage gets full instrumentation automatically.

## OTEL Middleware

File: `packages/pip/src/arc_guard/middleware/otel/__init__.py`.

GitNexus-confirmed functions (`histogram`, `_get_or_create_histogram`). The OTEL middleware implements the `MetricSink` Protocol using OpenTelemetry — available under the `[otel]` extra. The `_get_or_create_histogram` pattern avoids recreating instruments per call, satisfying OTEL's "one instrument per name" constraint.

Activated by wiring `OtelMetricSink` as the `metric_sink` argument at pipeline construction. Falls back to `NullMetricSink` without the extra installed — `test_histogram_swallows_create_failure.py` verifies this swallows transport failures silently.

## Payload-Safe Telemetry

A core invariant: **raw PII strings never appear in any telemetry surface under default settings.**

Enforced by:

- `test_no_raw_payload_in_decision_record.py` — `DecisionRecord` carries no raw text
- `test_no_raw_payload_in_sink_default.py` — `lifecycle_capture_raw_input=False` by default
- `Scan_for_leaks → _has_chunk` execution flow — a leak scanner that checks captured artifacts

The `bind` helper in `packages/core/src/arc_guard_core/observability.py` is the safe span attribute setter — it validates that attribute values pass the payload-safety allow-list before binding to a span.

## Metric Allow-List

`MetricSink` implementations enforce an attribute allow-list. Only pre-approved keys can be attached to histograms/counters. Custom keys are rejected unless explicitly added to the allow-list:

- `test_metric_path_accepts_allow_listed_key.py` — confirm allow-listed keys pass
- `test_default_allow_list_rejects_custom_key.py` — confirm un-listed keys are rejected
- `test_default_allow_list_rejects_custom_key.py` → `test_metric_attribute_allow_list_extension.py` — confirm extension mechanism works

## Failure Posture Rules (spec 004)

| Situation                     | Posture                  | Rationale                                                   |
| ----------------------------- | ------------------------ | ----------------------------------------------------------- |
| Inspector raises              | Fail-open                | A broken detector is safer than blocking all traffic        |
| Reporter/Logger/Tracer raises | Fail-open                | Side channels must not affect request outcome               |
| LifecycleSink raises          | Fail-open                | Dropped event is preferable to failed request               |
| Sanitization strategy raises  | Fail-closed              | A broken transformation cannot be trusted                   |
| PolicyRouter raises           | Fail-closed              | A missing decision cannot default to "allow"                |
| RehydrationVerifier raises    | Fail-closed-conservative | Keep placeholders in place rather than rehydrating unsafely |

## Concurrency Hardening

- `run_off_loop()` (`packages/pip/src/arc_guard/concurrency/offload.py`) — offloads blocking work (Presidio NER, model inference) away from the asyncio event loop
- Immutable contract objects — `Finding`, `PolicyDecision`, `GuardResult` are frozen dataclasses; no shared mutable state between concurrent requests
- `Logger`, `Tracer`, `MetricSink` implementations are required to be thread-safe
- Recursion correlation: `test_inner_run_records_parent_correlation_id.py` — nested pipeline calls (e.g., self-healing) record a parent `correlation_id` so traces don't lose hierarchy
