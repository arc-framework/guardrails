# Inspection Subsystem

## The Inspector Protocol

Defined in `packages/core/src/arc_guard_core/` (exact file: // VERIFY — check `protocols.py` or `types.py`). Structural typing via PEP 544:

```python
class Inspector(Protocol):
    def inspect(self, guard_input: GuardInput) -> list[Finding]: ...
```

Any class implementing `inspect(guard_input)` is a valid inspector — no base class, no registration decorator required. The `@runtime_checkable` annotation allows `isinstance()` checks at pipeline construction time.

The optional `ExplainableInspector` protocol (Provisional) adds `inspect_with_explanation()` which surfaces `InspectorMatchExplain` lifecycle events with per-match rationale.

## What a `Finding` Contains

`Finding` is a frozen dataclass from `packages/core/src/arc_guard_core/types.py`:

| Field         | Type            | Validated by                                                     |
| ------------- | --------------- | ---------------------------------------------------------------- |
| `inspector`   | `str`           | Non-empty (`_validate_finding` in `pipeline.py`)                 |
| `entity_type` | `str`           | Convention: `PERSON`, `CREDIT_CARD`, `JAILBREAK_ROLE_PLAY`, etc. |
| `start`       | `int`           | `>= 0`, `< end`                                                  |
| `end`         | `int`           | `> start`                                                        |
| `risk_level`  | `RiskLevel`     | Must be a valid `RiskLevel` enum member                          |
| `score`       | `float \| None` | `0.0–1.0` if present                                             |
| `metadata`    | `dict \| None`  | Arbitrary inspector-specific payload                             |

## Concrete Inspectors

```mermaid
graph TD
  subgraph Pattern["Pattern-based — no ML, fastest"]
    A[RegexPromptInjectionInspector]
    B[SqlInjectionInspector]
    C[ShellInjectionInspector]
  end
  subgraph NER["NER / Statistical"]
    D[PresidioNerInspector\nPII · PCI · PHI]
  end
  subgraph ML["ML-assisted — optional extras"]
    E["SemanticContentInspector\n[semantic] extra"]
    F["JailbreakDetector\nheuristic default + [jailbreak-ml] ML"]
  end
  subgraph Conv["Multi-turn — separate stage"]
    G[ConversationTurnInspector\nSTAGE_DECEPTION_INSPECT]
  end
```

### Regex Prompt Injection Inspector

Pattern-based detection of prompt injection markers. Fastest inspector — zero model calls. Detects: instruction override tokens, role-play framing markers, delimiter injection.

File: `packages/pip/src/arc_guard/inspectors/` (// VERIFY: exact module name).

### Presidio NER Inspector

Wraps Microsoft Presidio for Named Entity Recognition. Detects PII/PCI entities: `PERSON`, `EMAIL_ADDRESS`, `PHONE_NUMBER`, `CREDIT_CARD`, `IBAN_CODE`, `US_SSN`, `MEDICAL_LICENSE`, and custom entity types via the hot-reloadable registry.

Produces `FindingProduced` lifecycle events for each span. The `InspectorRan` event records total span count and duration.

**Fail-open**: if Presidio raises, `InspectorFailed` fires and the pipeline continues with zero findings from this inspector.

### Semantic Classifier (`[semantic]` extra)

DistilBERT-backed classifier for intent-level classification. Activated only when the `[semantic]` extra is installed. Integrates with the `IntentEncoder` Protocol — the same embedding used for fidelity scoring can be reused here.

Conformance tested by `packages/pip/tests/middleware/test_semantic_conformance.py`.

### Custom Entity Registry

Hot-reloadable entity definitions. Operators supply a list of patterns and entity types; the registry compiles them at startup and supports live reload without service restart.

### SQL Injection Inspector

File: `packages/pip/src/arc_guard/inspectors/code_injection/sql.py`.

GitNexus-confirmed functions (Code_injection cluster, 79% cohesion):

- `_detect_stacked()` — detects stacked queries (e.g., `; DROP TABLE`)
- `_detect_union()` — detects UNION-based injection patterns
- `_detect_comment_terminator()` — detects `--` and `#` comment terminators used to truncate queries
- `_leading_keyword()` — helper for keyword extraction
- `_emit_unparseable()` — emits a finding when SQL is structurally malformed in a suspicious way
- `inspect()` — the Protocol entry point

Runs in `STAGE_CLASSIFY` (pre-process phase only, by default — `test_pre_process_phase_skipped_by_default.py`).

### Shell Injection Inspector

File: `packages/pip/src/arc_guard/inspectors/code_injection/shell.py`.

GitNexus-confirmed functions:

- `_scan()` — main scan loop
- `_looks_like_shell_command()` — heuristic detection of shell metacharacters
- `_matching_close()` — bracket/quote balance checker
- `_make_finding()` — constructs the `Finding` from a match

### Jailbreak Detector

File: `packages/pip/src/arc_guard/jailbreak/detector.py`.

GitNexus-confirmed functions: `detect()`, `_scan()`.

Detects 6 jailbreak categories (confirmed by test names in the Jailbreak cluster):

1. **Direct override** — explicit "ignore previous instructions" patterns
2. **Role-play coercion** — "pretend you are", "act as", "you are now"
3. **Hypothetical framing** — "in a fictional world where", "theoretically speaking"
4. **Policy erosion** — gradual weakening across turns
5. **Indirect injection** — injections embedded in context, documents, or tool outputs
6. **Multi-turn escalation** — low-signal individual turns combining into a high-signal aggregate

Each signal becomes a `Finding` with `entity_type` set to the jailbreak category. The evidence reference in `JailbreakDetected` is a placeholder, not raw text — enforced by `test_evidence_reference_is_placeholder_not_raw_text.py`.

False positive rate < 5% on benign control inputs, verified by `test_benign_control_false_positive_rate_below_5_percent.py`.

## Inspector Failure Posture

From spec 004: inspector failures are **fail-open**. If `inspect()` raises:

1. `InspectorFailed` lifecycle event fires with the exception type and message (no stack trace in prod)
2. The pipeline continues with zero findings from that inspector
3. The failed inspector's result never blocks the request

This ensures a broken Presidio model or a network-dependent inspector can't take down the entire pipeline.
