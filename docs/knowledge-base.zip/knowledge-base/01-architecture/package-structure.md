# Package Structure

## The Three-Package Split

The rewrite (spec 002) reorganized the pre-rewrite monolith into three discrete packages, each with a clear responsibility boundary. The import direction is strictly one-way and enforced by an install-closure contract test (`packages/core/tests/integration/test_install_closure.py`).

```
arc_guard_service  →  arc_guard  →  arc_guard_core
```

```mermaid
graph LR
  CORE["**arc-guard-core**\nzero-dep contracts\nProtocol definitions\nFinding · GuardInput · LifecycleSink"]
  PIP["**arc-guard**\nbatteries-included\ninspectors · strategies\njailbreak · rehydration · pipeline"]
  API["**arc-guard-service**\nFastAPI transport\nHTTP routes · SSE\nSQLite lifecycle sink"]
  CORE -->|imported by| PIP -->|imported by| API
```

### `packages/core/` — `arc-guard-core`

**Role:** Zero-dependency contract layer.

Contains only what every consumer of the SDK needs to understand without pulling in heavy runtimes. This package has no non-stdlib runtime dependencies — a design invariant verified by the install-closure test.

Contents:

- Typed data models: `GuardInput`, `GuardResult`, `Finding`, `PolicyDecision`, `DecisionRecord`, `RefusalEnvelope`, `ClarificationRequest`, `FidelityScore`, `ConversationState`
- All `Protocol` definitions (PEP 544): `Guard`, `Inspector`, `ActionStrategy`, `PolicyRouter`, `Reporter`, `FlagProvider`, `IntentEncoder`, `FidelityScorer`, `RehydrationVerifier`, `JailbreakDetector`, `ConversationTurnInspector`, `LifecycleSink`
- Stage descriptor constants: `STAGE_VALIDATE` … `STAGE_REPORT` (`stages.py`)
- Exception hierarchy: `ArcGuardError` → 14 subtypes (`exceptions.py`)
- `GuardPipeline` contract shape (empty harness — no inspectors wired, `pipeline.py`)
- Lifecycle event taxonomy: 29 frozen dataclasses (`lifecycle/events.py`)
- `LifecycleSink` Protocol + `NullLifecycleSink` default (`lifecycle/sink.py`)
- Placeholder registry (`placeholders.py`)
- Intent lock (`intent_lock.py`)
- Dashboard read models: `RequestSummary`, `RequestPage`, `RequestWorkspaceManifest`, etc. (`schemas/`)

**Distribution floor:** Python ≥ 3.11, `pydantic ≥ 2.0`.

### `packages/pip/` — `arc-guard`

**Role:** Batteries-included runtime library.

All concrete implementations live here — inspectors, strategies, pipeline orchestration, middleware, reporters, evaluation harness, and optional adapter extras. This is what operators install when they want a working guardrail with no integration work.

Contents:

- `GuardPipeline` full implementation with inspector chain, policy router, strategies, and reporters (`src/arc_guard/pipeline.py` — note: scope extraction currently fails in GitNexus due to complexity; the contract-layer `GuardPipeline` in `core` is the indexed version)
- Inspectors: regex prompt injection, Presidio NER, custom entity registry, semantic classifier (`[semantic]` extra), SQL injection (`inspectors/code_injection/sql.py`), shell injection (`inspectors/code_injection/shell.py`)
- Jailbreak detector — 6 categories: direct override, role-play coercion, hypothetical framing, policy erosion, indirect injection, multi-turn escalation (`jailbreak/detector.py`)
- Strategies: `redact`, `hash`/pseudonymize, `tokenize`, `warn`, `block`
- `DefaultStrategySelector` + `SemanticContentPolicy`
- Lifecycle sink implementations: `RingBufferLifecycleSink` (5,000 rid capacity, OrderedDict-backed), `SqliteLifecycleSink` (stdlib `sqlite3` + JSON1, 500k row / 7-day retention), `CompositeLifecycleSink` (sequential fan-out with per-child failure isolation), `BroadcastingLifecycleSink` (wraps a sink + SSE subscriber registry) — all in `observability/`
- Dashboard observability writers: `request_summary_projector`, `decision_record_recorder`, `debug_log_handler`, `debug_entry_writer` (`observability/`)
- OTEL middleware (`middleware/otel/__init__.py`)
- Semantic middleware: `IntentEncoder`, `FidelityScorer` canned implementations (`middleware/semantic/`)
- Evaluation harness: `evaluate()`, 4 pipeline configurations (`evaluation/harness.py`)
- Concurrency helpers: `run_off_loop` for blocking work (`concurrency/offload.py`)
- Rehydration verifier (`rehydration/`)

**Optional extras:** `[semantic]` (sentence-transformers), `[jailbreak-ml]` (transformer classifier), `[otel]` (OpenTelemetry SDK).

### `packages/api/` — `arc-guard-service`

**Role:** Thin deployment surface. No guardrail logic lives here.

A FastAPI application that wires `arc-guard` into an HTTP service. It owns transport, settings, CORS, and the dashboard data plane routes — nothing else.

Contents:

- `guard_endpoint` — the main `/v1/guard` POST handler (`transport/http.py:385`)
- OpenAI-compatible chat-completions transport (`transport/openai.py`)
- Dashboard read routes: `list_requests` (`transport/requests.py:164`), `get_request_decision`, `get_request_debug` — all in `transport/requests.py`
- SSE events endpoint: `GET /events` + `?rid=` filter (`transport/events.py`)
- `ServiceSettings` (pydantic-settings): all operator knobs including `dashboard_origins`, `lifecycle_*` flags, page-size caps
- Request-scope rid middleware + `X-Request-Id` response header (`transport/_rid.py`)
- Strict CORS allow-list middleware (no wildcards, GET/OPTIONS only, `Access-Control-Max-Age: 600`)

**Distribution floor:** Python ≥ 3.11, `fastapi ≥ 0.110`, `uvicorn ≥ 0.30`, `pydantic-settings ≥ 2.0`.
