# Lifecycle Sink

## What it is

The lifecycle sink is the **fourth observability surface** in arc-guardrails, independent of the existing three (`Reporter`, `Logger`, `MetricSink`). It emits typed, parent-id-linked events that form a directed acyclic graph per request — enabling both live inspection and forensic replay.

Source: `packages/core/src/arc_guard_core/lifecycle/` (protocol + events), `packages/pip/src/arc_guard/observability/` (concrete sinks).

## LifecycleSink Protocol

Defined at `packages/core/src/arc_guard_core/lifecycle/sink.py`:

```python
class LifecycleSink(Protocol):
    async def emit(self, event: LifecycleEvent) -> None: ...
    async def query(self, rid: str) -> list[LifecycleEvent] | None: ...
    async def close(self) -> None: ...
```

**Failure mode: open.** Sink implementations MUST NOT propagate exceptions back into the pipeline or transport. The orchestrator catches and counts failures. A dropped event never affects the request outcome.

**Concurrency:** async, called from the asyncio event loop. Implementations must be thread-safe within the event loop.

**Default:** `NullLifecycleSink` — discards every event, returns `None` for every query. Constructing `GuardPipeline` without `lifecycle_hook=` gets this sink, ensuring zero behavioral change for operators not opting in.

## The 29 Typed Event Classes

All defined in `packages/core/src/arc_guard_core/lifecycle/events.py`. All `frozen=True`. Every event inherits from `LifecycleEventBase` which carries: `id` (UUID), `parent_id`, `seq` (monotonic per-rid counter), `ts` (UTC timestamp), `rid` (request correlation id), `event_type` (string discriminator).

| Event                                | When it fires                                                                               |
| ------------------------------------ | ------------------------------------------------------------------------------------------- |
| `RequestStarted`                     | Entry to pre_process transport handler                                                      |
| `PreProcessCompleted`                | pre_process returns                                                                         |
| `PostProcessStarted`                 | Entry to post_process                                                                       |
| `PostProcessCompleted`               | post_process returns                                                                        |
| `StageRan`                           | Every stage exit (stage name, duration_ms, outcome)                                         |
| `InspectorRan`                       | Each inspector completion                                                                   |
| `InspectorFailed`                    | Inspector raised an exception (fail-open captured)                                          |
| `FindingProduced`                    | Each `Finding` emitted by an inspector                                                      |
| `PlaceholderMapBuilt`                | Sanitization placeholder map assembled                                                      |
| `SanitizationApplied`                | Sanitization complete; optional `text_after` under payload-capture flag                     |
| `PolicyRuleEvaluated`                | Each policy rule evaluation                                                                 |
| `PolicyResolved`                     | Final `PolicyDecision` set resolved                                                         |
| `StrategyExecuted`                   | Each `ActionStrategy` application                                                           |
| `RefusalProduced`                    | `RefusalEnvelope` constructed                                                               |
| `BackendCalled`                      | Downstream LLM/backend call initiated; optional `model_config_snapshot`                     |
| `BackendResponded`                   | Backend response received; optional `token_usage`                                           |
| `ResponseAssembled`                  | Final `GuardResult` assembled                                                               |
| `DecisionEmitted`                    | `DecisionRecord` written                                                                    |
| `RehydrationVerified`                | Rehydration verifier verdict                                                                |
| `JailbreakDetected`                  | Jailbreak signal above threshold; optional `evidence_reference` (placeholder, not raw text) |
| `DeceptionScored`                    | Deception turn score computed; optional `marker_counts`                                     |
| `RequestCompleted`                   | Final event — always fires, even on error paths                                             |
| _(+ 7 more conditional event types)_ | // VERIFY: count from `events.py` `__all__`                                                 |

## Three Concrete Sink Implementations

### `RingBufferLifecycleSink`

- In-memory, `OrderedDict`-backed per-rid storage
- Default capacity: **5,000 rids** (configurable via `lifecycle_buffer_capacity`)
- Drop-oldest eviction when capacity exceeded
- `query()` returns events sorted by `seq`
- Zero persistence — lost on service restart

**Use case:** Development and low-latency paths where SQLite write overhead is undesirable.

### `SqliteLifecycleSink`

- Stdlib `sqlite3` + JSON1 extension — no third-party dependencies
- Three tables (schema v2, spec 012): `request_summaries`, `decision_records`, `debug_entries`
- Retention: 500,000 rows **or** 7 days (whichever stricter) — GC runs as a background task, evicting all three tables in a single transaction
- Forward-only schema migration, idempotent on repeated startup
- `lifecycle_sqlite_path` controls the database file path; `None` → in-memory only (useful for tests)

**Use case:** Production — survives service restarts, feeds the dashboard read routes.

### `CompositeLifecycleSink`

- Sequential fan-out to N child sinks
- Per-child failure counters; one child failing does not abort the others
- The default service composite is: `RingBufferLifecycleSink → SqliteLifecycleSink → BroadcastingLifecycleSink`

### `BroadcastingLifecycleSink` _(Provisional)_

- Wraps a storage sink + an SSE subscriber registry
- Delivers events to all connected SSE clients in real-time
- Subscribers connect via `GET /events`; optional `?rid=` filter narrows to one request

## SQLite Schema (v2)

Three tables added by spec 012, on top of the original `lifecycle_events` table from spec 010:

| Table               | Key                  | Purpose                                                         |
| ------------------- | -------------------- | --------------------------------------------------------------- |
| `lifecycle_events`  | `(rid, seq)`         | Raw event storage (JSON1)                                       |
| `request_summaries` | `rid`                | Writer-side projection for the explorer table (`GET /requests`) |
| `decision_records`  | `(rid, decision_id)` | `DecisionRecord` payloads for `GET /requests/{rid}/decision`    |
| `debug_entries`     | `(rid, seq)`         | Structured log lines captured by `debug_log_handler`            |

The `request_summary_projector` writes incrementally to `request_summaries` as lifecycle events arrive — O(1) per event, O(log n) reads for the dashboard.

## Operator Knobs (`ServiceSettings`)

| Field                           | Default | Description                                                          |
| ------------------------------- | ------- | -------------------------------------------------------------------- |
| `lifecycle_buffer_capacity`     | 5,000   | Ring-buffer rid capacity                                             |
| `lifecycle_sqlite_path`         | `None`  | SQLite file path; `None` = in-memory                                 |
| `lifecycle_sqlite_max_rows`     | 500,000 | Row cap before GC runs                                               |
| `lifecycle_sqlite_max_age_days` | 7       | Age cap in days                                                      |
| `lifecycle_capture_payloads`    | `False` | Include post-sanitization text in `SanitizationApplied.text_after`   |
| `lifecycle_capture_raw_input`   | `False` | Include raw input in `RequestStarted.raw_input` (security-sensitive) |
