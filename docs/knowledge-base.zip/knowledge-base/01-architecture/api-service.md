# API Service

## Overview

`arc-guard-service` is a **stateless FastAPI application** that exposes the guardrail pipeline and the operator dashboard over HTTP. It owns transport, settings, and CORS — no guardrail logic lives in this package. All imports flow `api → pip → core`.

Root files: `packages/api/src/arc_guard_service/`.

## Guard Endpoints

### `POST /v1/guard` — `guard_endpoint`

Defined at `packages/api/src/arc_guard_service/transport/http.py:385–433`.

The primary entry point. Receives a JSON payload, mints a `rid` (request id) via `_mint_rid()` (`transport/_rid.py`), runs `GuardPipeline.pre_process()`, serializes the `GuardResult` via `_result_to_dict()` or `_envelope_to_dict()` (for refusals), and returns the response.

The `rid` is echoed in the `X-Request-Id` response header so callers can correlate dashboard data.

### OpenAI-compatible transport

`transport/openai.py` provides an OpenAI chat-completions compatible endpoint. It wraps the same pipeline call with `_build_model_config_snapshot()` for the `BackendCalled` lifecycle event and `_extract_token_usage()` for `BackendResponded`.

## Dashboard Read Routes

All defined in `packages/api/src/arc_guard_service/transport/requests.py`. All are **read-only, unauthenticated** — operators are expected to layer an auth proxy in production.

### `GET /requests` — `list_requests` (line 164)

Paginated request explorer. Reads from the `request_summaries` SQLite table. Supports cursor-based pagination and filters:

- `_build_filter_clause()` — constructs the SQL WHERE clause from `RequestPageFilters`
- `_row_to_summary()` — maps a SQLite row to a `RequestSummary` pydantic model
- `_open_read_conn()` — opens a read-only SQLite connection
- `_dashboard_unavailable()` — returns 503 when SQLite path is not configured

Response: `RequestPage` (items + next cursor + effective filters echo).

### `GET /requests/{rid}` — workspace manifest

Returns `RequestWorkspaceManifest`: the canonical `RequestSummary` plus a `WorkspaceResourcesAvailability` map indicating which subordinate resources (lifecycle replay, decision record, debug entries, live SSE) are available. Missing resources return clean 404/503 — they fail independently.

### `GET /requests/{rid}/decision` — `get_request_decision`

Returns `RequestDecisionEnvelope` containing the `DecisionRecord` for that rid. Reads from the `decision_records` table.

### `GET /requests/{rid}/debug` — `get_request_debug`

Returns `RequestDebugPage` — cursor-paginated debug log entries from the `debug_entries` table. Debug entries are structured log lines captured by the `debug_log_handler` logging handler that taps on `rid_context_var`.

## SSE Events Endpoint

`GET /events` — defined in `packages/api/src/arc_guard_service/transport/events.py`.

Streams lifecycle events as Server-Sent Events. Additive `?rid=<rid>` filter narrows the stream to a single request. When the targeted rid completes, a terminal sentinel event is sent and the stream closes cleanly — no zombie connections.

`_is_already_terminated()` checks the SQLite store before opening a stream for a completed rid, returning the full replay immediately instead of blocking.

## CORS Configuration

Strict allow-list, configured via `ServiceSettings.dashboard_origins` (comma-separated list):

- No wildcards — `*` is rejected at startup
- Only `http`/`https` schemes — `ws://` etc. rejected
- No trailing slashes, paths, queries, or fragments in origin strings
- Allowed methods: `GET`, `OPTIONS` only (no `POST`, no credentials)
- Allowed headers: `Content-Type`, `Cache-Control`, `Last-Event-ID`
- `Access-Control-Max-Age: 600`
- **Default-deny**: empty `dashboard_origins` installs no CORS middleware

## ServiceSettings Knobs (Dashboard)

| Field                                      | Default | Env var                                                      |
| ------------------------------------------ | ------- | ------------------------------------------------------------ |
| `dashboard_origins`                        | `[]`    | `ARC_GUARD_SERVICE_DASHBOARD_ORIGINS`                        |
| `dashboard_max_request_page_size`          | 200     | `ARC_GUARD_SERVICE_DASHBOARD_MAX_REQUEST_PAGE_SIZE`          |
| `dashboard_max_debug_page_size`            | 200     | `ARC_GUARD_SERVICE_DASHBOARD_MAX_DEBUG_PAGE_SIZE`            |
| `dashboard_decision_record_queue_capacity` | 1,000   | `ARC_GUARD_SERVICE_DASHBOARD_DECISION_RECORD_QUEUE_CAPACITY` |
| `dashboard_debug_entry_queue_capacity`     | 5,000   | `ARC_GUARD_SERVICE_DASHBOARD_DEBUG_ENTRY_QUEUE_CAPACITY`     |

All dashboard writers (`decision_record_recorder`, `debug_entry_writer`) are non-blocking with dropped-write counters. A SQLite write failure under load drops a dashboard row; the guard request path is unaffected.
