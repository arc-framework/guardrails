# Strategy Subsystem

## Overview

After `STAGE_CLASSIFY` produces `Finding` objects and `STAGE_ROUTE` resolves `PolicyDecision` objects, `STAGE_EXECUTE` applies concrete transformations via the `ActionStrategy` Protocol. The strategy subsystem also includes the `StrategySelector` and `ContentPolicy` Protocols introduced in spec 011.

## The ActionStrategy Protocol

Structural typing (PEP 544). Any class implementing `apply()` is a valid strategy:

```python
class ActionStrategy(Protocol):
    def apply(self, text: str, findings: list[Finding]) -> str: ...
```

Strategies are stateless transformers — they receive the text and the relevant findings, return the transformed text. A `StrategyExecuted` lifecycle event fires for each application.

## The Five Built-in Strategies

| Strategy              | `entity_type` use case                  | Transformation                                                       |
| --------------------- | --------------------------------------- | -------------------------------------------------------------------- |
| `redact`              | PII, PCI, PHI                           | Replace span with typed placeholder: `[CREDIT_CARD_1]`, `[PERSON_2]` |
| `hash` / pseudonymize | Analytics joins, reference preservation | HMAC-SHA256 digest of the span — deterministic, reversible with key  |
| `tokenize`            | Repeated entity references              | Typed placeholder with stable numbering across repeated occurrences  |
| `warn`                | Low-risk policy flags                   | Preserve content, elevate decision rationale in `PolicyDecision`     |
| `block`               | Critical risk, jailbreak                | Stop processing; trigger `STAGE_REFUSAL`                             |

The `redact` strategy's **typed placeholder numbering** is the key innovation over generic masking: `[CREDIT_CARD_1]` vs `[CREDIT_CARD_2]` preserves which card is which through sanitization, allowing the downstream LLM to reason about multiple entities without seeing their raw values.

## StrategySelector Protocol (spec 011)

Introduced in `packages/pip/src/arc_guard/` (// VERIFY: exact file). The `StrategySelector` decides which `ActionStrategy` to apply for a given `Finding` and policy context:

```python
class StrategySelector(Protocol):
    def select(self, finding: Finding, policy: ContentPolicy) -> ActionStrategy: ...
```

`DefaultStrategySelector` is the batteries-included implementation — it maps `RiskLevel` to strategy using the four risk bands (LOW → redact, MEDIUM → redact+warn, HIGH → partial block, CRITICAL → block).

## ContentPolicy Protocol (spec 011)

```python
class ContentPolicy(Protocol):
    def evaluate(self, finding: Finding) -> PolicyDecision: ...
```

`SemanticContentPolicy` uses embedding similarity to route findings into policy decisions when simple rule matching is insufficient. This is the `[semantic]` extra path.

## Risk Band → Strategy Mapping

```mermaid
flowchart LR
  L[LOW] -->|redact| R[RedactStrategy]
  M[MEDIUM] -->|redact + warn| R & W[WarnStrategy]
  H[HIGH] -->|partial block| B[BlockStrategy]
  C[CRITICAL] -->|hard block| B
  B --> RE[RefusalEnvelope]
  R --> RH[RehydrationVerifier]
```

The `PolicyRouter` (via `STAGE_ROUTE`) resolves the risk band. The `StrategySelector` (via `STAGE_EXECUTE`) maps the band to a strategy:

| Risk Band  | Default Strategy  | Output                                                         |
| ---------- | ----------------- | -------------------------------------------------------------- |
| `LOW`      | `redact`          | Sanitized text, `action="sanitize"`                            |
| `MEDIUM`   | `redact` + `warn` | Sanitized text, `action="warn"`, warning in `GuardResult`      |
| `HIGH`     | `block` (partial) | Sanitized text + `RefusalEnvelope`, `action="partial_refusal"` |
| `CRITICAL` | `block` (full)    | No text released, only `RefusalEnvelope`, `action="block"`     |

## Refusal and Clarification

When the outcome is `HIGH` or `CRITICAL`, `STAGE_REFUSAL` assembles a `RefusalEnvelope` containing:

- Which findings triggered the decision
- Which policy rule fired
- Machine-readable rationale
- Suggested next action for the caller

When the risk is ambiguous but recoverable, the router can emit a `ClarificationRequest` instead of a hard refusal — giving the caller a structured path to reformulate the request.

## Extension Example

```python
class CustomHashStrategy:
    def apply(self, text: str, findings: list[Finding]) -> str:
        for f in findings:
            digest = hmac.new(key, text[f.start:f.end].encode()).hexdigest()[:8]
            text = text[:f.start] + f"[CUSTOM_{digest}]" + text[f.end:]
        return text
```

No base class. No registration. Pass to `GuardPipeline` constructor as part of the strategy registry.
