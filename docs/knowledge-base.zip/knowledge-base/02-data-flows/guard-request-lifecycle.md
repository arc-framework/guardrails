# Guard Request Lifecycle — End-to-End Walkthrough

This document traces a complete guard request from HTTP entry to response, naming every significant class on the call path with its file location.

## Entry Point: HTTP Transport

1. **Client** sends `POST /v1/guard` (or OpenAI-compatible `POST /v1/chat/completions`)

2. **`guard_endpoint`** (`packages/api/src/arc_guard_service/transport/http.py:385`) receives the request. It:
   - Calls `_mint_rid()` (`transport/_rid.py`) to generate a UUID-based request id
   - Sets `rid_context_var` (contextvar for the debug log handler)
   - Attaches `rid` to the `X-Request-Id` response header
   - Constructs a `GuardInput` from the validated request body

3. **Lifecycle entry:** `LifecycleEmitter.emit(RequestStarted(...))` fires through the composite sink chain

```mermaid
sequenceDiagram
  participant Client
  participant guard_endpoint
  participant LifecycleEmitter
  participant GuardPipeline
  Client->>guard_endpoint: POST /v1/guard (GuardInput)
  guard_endpoint->>LifecycleEmitter: emit RequestStarted(rid)
  guard_endpoint->>GuardPipeline: pre_process(GuardInput)
  GuardPipeline->>GuardPipeline: stages 1–12
  GuardPipeline-->>guard_endpoint: GuardResult(action, findings)
  guard_endpoint->>LifecycleEmitter: emit RequestCompleted
  guard_endpoint-->>Client: 200 OK / 422
```

## Pipeline Execution (`arc_guard.pipeline`)

The full `GuardPipeline` implementation lives at `packages/pip/src/arc_guard/pipeline.py` (// VERIFY: scope extraction fails in GitNexus; line numbers unconfirmed). The contract-layer shape is at `packages/core/src/arc_guard_core/pipeline.py`.

`pre_process(guard_input)` →

### Stage 1: validate

`stage_runner` wraps the stage. `_validate_finding()` / `_validate_decision()` patterns from `pipeline.py` enforce contract invariants. Any violation raises `PipelineContractValidationError`.

### Stage 2: defend

`IntentEncoder.encode(guard_input.text)` → opaque representation stored in an `IntentLock` (`packages/core/src/arc_guard_core/intent_lock.py`). Skipped when no encoder configured.

### Stage 3: classify

All registered `Inspector` implementations run:

```
RegexPromptInjectionInspector.inspect(guard_input) → [Finding, ...]
PresidioNerInspector.inspect(guard_input)           → [Finding, ...]   # via run_off_loop
SqlInjectionInspector.inspect(guard_input)          → [Finding, ...]
ShellInjectionInspector.inspect(guard_input)        → [Finding, ...]
JailbreakDetector.detect(guard_input.text)          → [JailbreakSignal, ...] → [Finding, ...]
```

Each `Finding` fires a `FindingProduced` lifecycle event. Inspector failures fire `InspectorFailed` and are swallowed (fail-open).

### Stage 4: deception_inspect

`ConversationTurnInspector.score(turn, state)` updates `ConversationState`. `DeceptionScored` lifecycle event fires. Skipped when `ConversationState` is not provided.

### Stage 5: sanitize

For each finding selected by `ContentPolicy.evaluate()`:

- Placeholder map assembled → `PlaceholderMapBuilt` event
- Spans replaced → `SanitizationApplied` event

### Stage 6: route

`PolicyRouter.route(findings, config)` → `list[PolicyDecision]`. Each rule evaluation → `PolicyRuleEvaluated`. Final resolution → `PolicyResolved`.

If aggregate risk is `CRITICAL` → skip stages 7–10, jump to stage 8 (refusal).

### Stage 7: execute

Sanitized prompt sent to downstream backend. `BackendCalled` event (with optional `model_config_snapshot`). Backend responds → `BackendResponded` event (with optional `token_usage`). `StrategyExecuted` events fire for applied strategies.

### Stage 8: refusal

Only if `HIGH` or `CRITICAL` risk. `RefusalEnvelope` assembled → `RefusalProduced` event. For `CRITICAL`, pipeline exits here with `GuardResult(action="block")`.

### Stage 9: verify

`FidelityScorer.score(intent_lock, answer)` → `FidelityScore`. Fidelity ladder applied. `RehydrationVerified` event fires.

### Stage 10: rehydrate

`RehydrationVerifier.verify(answer, placeholder_map)` checks structural and semantic safety. If safe: full rehydration. If not: partial rehydration or keep placeholders. `ResponseAssembled` event.

### Stage 11: decision_emit

`DecisionRecord` assembled and emitted → `DecisionEmitted` event. `decision_record_recorder` writes to SQLite `decision_records` table asynchronously.

### Stage 12: report

`Reporter.report(guard_result)` fires (non-authoritative side channel). `RequestCompleted` lifecycle event — always fires, even on error paths.

## Return Path

`GuardPipeline` returns `GuardResult` to `guard_endpoint`, which serializes via `_result_to_dict()` (normal) or `_envelope_to_dict()` (refusal) and returns `200 OK` or `422`.

## Dashboard Side Channel (Async)

In parallel with the above, `BroadcastingLifecycleSink` delivers every `LifecycleEvent` to all connected SSE clients at `GET /events`. This path is fully independent of the request path — a stalled SSE client cannot block the guardrail response.

## Latency Budget

From the dissertation (pre-rewrite baseline; current numbers // VERIFY):

- Lite mode (regex + Presidio): P99 < 25ms
- Full semantic mode (+ DistilBERT): P99 < 150ms
- All processing in-process, zero network hops to external sanitization service
