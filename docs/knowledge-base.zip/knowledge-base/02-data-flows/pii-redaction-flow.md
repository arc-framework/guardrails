# PII Redaction Flow

This document traces a PII-redaction request end-to-end — the most common production use case. A customer support message containing a credit card number and customer name is intercepted, sanitized, forwarded to the LLM, and the answer is rehydrated before being returned.

## Input

```
User: "My name is Jane Smith and my card ending in 4242 is being declined.
Card number: 4532-1234-5678-4242. Can you help?"
```

## 1. Transport Entry

`guard_endpoint` (`transport/http.py:385`) receives `POST /v1/guard`. `_mint_rid()` generates `rid = "01JGXYZ..."`. `RequestStarted` lifecycle event fires with `rid`.

## 2. Stage: validate

`GuardPipeline._run()` validates the `GuardInput`. Span boundaries are non-negative, text is within size limits. Passes.

## 3. Stage: defend

`IntentEncoder.encode("My name is Jane Smith...")` captures a semantic representation of the user's intent (get help with a declined card). Stored in `IntentLock`. This is what `STAGE_VERIFY` will compare the LLM's answer against.

## 4. Stage: classify — the core detection step

Three inspectors fire in parallel (via `run_off_loop` for blocking work):

**Presidio NER Inspector:**

```
Finding(inspector="presidio", entity_type="PERSON",       start=11, end=21, risk_level=LOW,    score=0.97)
Finding(inspector="presidio", entity_type="CREDIT_CARD",  start=58, end=77, risk_level=HIGH,   score=0.99)
```

`InspectorRan` lifecycle event: `inspector="presidio"`, `finding_count=2`, `duration_ms=14`.
`FindingProduced` events fire twice.

**Regex Prompt Injection Inspector:** no matches. `InspectorRan` event fires with `finding_count=0`.

**Jailbreak Detector:** no signals. `InspectorRan` event fires.

Aggregate: 2 findings, highest risk = `HIGH` (credit card).

## 5. Stage: deception_inspect

No `ConversationState` provided (single-turn request). Stage is a no-op pass.

## 6. Stage: sanitize

`ContentPolicy` routes both findings to the `redact` strategy.

`PlaceholderMapBuilt` event fires with the entity map:

- `[PERSON_1]` → `"Jane Smith"`
- `[CREDIT_CARD_1]` → `"4532-1234-5678-4242"`

Text after sanitization:

```
"My name is [PERSON_1] and my card ending in 4242 is being declined.
Card number: [CREDIT_CARD_1]. Can you help?"
```

`SanitizationApplied` lifecycle event fires. `text_after` is populated only if `lifecycle_capture_payloads=True` (default: off).

## 7. Stage: route

`PolicyRouter` evaluates: `CREDIT_CARD` at `HIGH` risk. Per the risk band table:

- `PERSON` at `LOW` → redact and continue
- `CREDIT_CARD` at `HIGH` → partial refusal? No — in this case, the credit card was already redacted. The router sees the `HIGH` finding but notes the strategy applied (redact) was sufficient. Aggregate risk after redaction: `MEDIUM`. Action: `warn`.

`PolicyResolved` event fires. `PolicyDecision` emitted with `strategy="redact"`, `rationale="PCI entity sanitized"`.

## 8. Stage: execute

Sanitized prompt sent to LLM backend. `BackendCalled` event fires (with `model_config_snapshot`). LLM responds:

```
"Hi [PERSON_1], I can see the issue with [CREDIT_CARD_1].
The card is showing as declined due to an address mismatch..."
```

`BackendResponded` event fires with `token_usage`.

## 9. Stage: verify

`FidelityScorer` compares the LLM answer's semantic content against the captured `IntentLock`. The answer addresses a declined card — high fidelity to the original intent. Score: `0.94` (above threshold). Continue.

`RehydrationVerified` lifecycle event fires with `verdict="allowed"`.

## 10. Stage: rehydrate

`RehydrationVerifier` checks: `[PERSON_1]` and `[CREDIT_CARD_1]` both map to known entities. Structure is preserved. Rehydration is safe.

Final text:

```
"Hi Jane Smith, I can see the issue with 4532-1234-5678-4242.
The card is showing as declined due to an address mismatch..."
```

`ResponseAssembled` lifecycle event fires.

## 11. Stage: decision_emit

`DecisionRecord` assembled: findings (entity types only, no raw spans), decisions (strategies applied), outcome (`action="warn"`), `IntentLock` hash. No raw PII in the record.

`DecisionEmitted` fires. `decision_record_recorder` writes asynchronously to `decision_records` SQLite table.

## 12. Stage: report

`Reporter.report(guard_result)` fires (non-blocking side channel). `RequestCompleted` fires.

## Response

`guard_endpoint` returns `200 OK` with `GuardResult`:

```json
{
  "text": "Hi Jane Smith, I can see the issue with 4532-1234-5678-4242...",
  "action": "warn",
  "findings": [
    { "entity_type": "PERSON", "risk_level": "LOW" },
    { "entity_type": "CREDIT_CARD", "risk_level": "HIGH" }
  ],
  "fidelity_score": 0.94
}
```

Total: 2 findings detected, 2 redacted, 1 rehydration, 0 network hops to external sanitization services.
