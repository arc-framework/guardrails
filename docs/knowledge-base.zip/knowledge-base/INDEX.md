# Knowledge Base Index

This knowledge base describes the arc-guardrails system as it exists after the post-rewrite implementation. All content is grounded in the GitNexus semantic graph (9,374 symbols, 14,073 edges, 103 execution flows, indexed 2026-05-09).

## How to Use This KB

- **New to the system?** Start at `00-overview.md`, then read `01-architecture/guardrail-pipeline.md`.
- **Debugging a guard request?** Read `02-data-flows/guard-request-lifecycle.md` for the full call path, then the specific flow document for your scenario.
- **Adding an inspector or strategy?** Read `01-architecture/inspection-subsystem.md` and `03-decisions/protocol-over-inheritance.md` first — both explain why you don't need to subclass anything.
- **Writing about or presenting the system?** Read `04-thesis-material/README.md` for the dissertation mapping and the list of what changed between pre-rewrite and post-rewrite.
- **Working on canvas files?** Read `03-decisions/canvas-sync-policy.md` before editing anything in `docs/canvases/` or `apps/guardrail-flow/canvases/`.

---

## Contents

### `00-overview.md`

What arc-guardrails is, the problem it solves, the three-package architecture (`arc-guard-core` / `arc-guard` / `arc-guard-service`), and the design principles that govern all extension decisions.

---

### `01-architecture/`

| Document                  | What it covers                                                                                                                                                                 |
| ------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `guardrail-pipeline.md`   | All 12 stages, the `stage_runner` instrumentation hook, and the extension-point table (which Protocol governs each stage)                                                      |
| `package-structure.md`    | What lives in each package, distribution names, version floors, and the zero-dep invariant for `arc-guard-core`                                                                |
| `lifecycle-sink.md`       | `LifecycleSink` Protocol, all 29 typed events, the three concrete sinks (ring-buffer, SQLite, composite), SQLite schema v2, operator knobs                                     |
| `api-service.md`          | `guard_endpoint` entry point, the 4 dashboard HTTP routes, SSE `/events`, CORS config, `ServiceSettings` fields                                                                |
| `observability.md`        | The four independent observability surfaces (Logger, Tracer, MetricSink, LifecycleSink), the `stage_runner` emission pattern, payload-safety invariants, failure posture table |
| `inspection-subsystem.md` | `Inspector` Protocol, `Finding` fields, all concrete inspectors, 6 jailbreak categories, fail-open posture                                                                     |
| `strategy-subsystem.md`   | `ActionStrategy` Protocol, 5 strategies, `StrategySelector`, `ContentPolicy`, risk-band → strategy mapping                                                                     |

---

### `02-data-flows/`

| Document                     | Scenario                                                                                                                                |
| ---------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| `guard-request-lifecycle.md` | End-to-end call path for a guard request: HTTP entry → pipeline → response, naming every significant class                              |
| `pii-redaction-flow.md`      | PII redaction: Presidio detects PERSON + CREDIT_CARD, redact strategy applied, LLM sees sanitized text, answer rehydrated before return |
| `prompt-injection-flow.md`   | Prompt injection block: regex + jailbreak detectors fire CRITICAL findings, pipeline short-circuits at STAGE_ROUTE, LLM never reached   |

---

### `03-decisions/`

Architectural Decision Records (ADRs) document non-obvious choices and the alternatives that were ruled out.

| Document                       | Decision                                                                                                                            |
| ------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------- |
| `protocol-over-inheritance.md` | PEP 544 structural `Protocol` over ABC inheritance for all extension seams — operators implement without importing SDK base classes |
| `sqlite-lifecycle-sink.md`     | SQLite (stdlib `sqlite3`) as the durable lifecycle event store — zero external runtime dependencies, WAL mode, 4-table schema       |
| `canvas-sync-policy.md`        | `docs/canvases/` is source of truth; `apps/guardrail-flow/canvases/` is a derived copy synced via `scripts/sync-canvases.sh`        |

---

### `04-thesis-material/`

| Document    | Purpose                                                                                                                                                   |
| ----------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `README.md`               | Maps this KB to the BITS Pilani M.Tech dissertation (pre-rewrite baseline); tracks what the dissertation got right, what changed, and what needs revision |
| `detection-reference.md` | All 9 threat categories: inspector → entity type → action → difficulty gradient with examples, documented gaps, refusal code reference                     |

---

### `semantic-graph/`

| Document                      | Purpose                                                                                                                 |
| ----------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| `2026-05-09/GRAPH_SUMMARY.md` | Snapshot of the GitNexus index at the time of KB creation: cluster table, process inventory, top flows, orphan findings |

---

## Relationship to Other Docs

| Location            | Contents                                       | Relationship to this KB                                            |
| ------------------- | ---------------------------------------------- | ------------------------------------------------------------------ |
| `docs/walkthrough/` | One-page per-spec summaries                    | Spec-oriented; this KB is system-oriented                          |
| `docs/university/`  | Pre-rewrite dissertation source                | Historical baseline; `04-thesis-material/README.md` maps the delta |
| `docs/canvases/`    | Visual architecture canvases (Obsidian format) | Complement to this KB; diagrams rather than prose                  |
| `specs/`            | Governance artifacts and feature specs         | Planning; this KB is implementation description                    |
| `.specify/memory/`  | Operational patterns for spec authoring        | Authoring guide; this KB is system knowledge                       |

---

## Maintenance Notes

- This KB is grounded in the semantic graph index at `semantic-graph/2026-05-09/`. When the system changes materially, re-run `npx gitnexus analyze` and update the affected documents.
- The `00-overview.md` spec history table should be updated when a new spec ships.
- `01-architecture/lifecycle-sink.md` event table (29 events) is the most likely document to drift as new events are added.
- ADRs in `03-decisions/` are append-only; superseded decisions should be marked **Superseded** with a pointer to the new ADR.
