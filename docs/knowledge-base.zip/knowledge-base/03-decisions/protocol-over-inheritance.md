# ADR: Protocol over Inheritance for Extension Points

**Status:** Accepted  
**Date:** 2026-03-15 (spec 002 ratification)  
**Applies to:** All extension seams in `arc-guard-core` and `arc-guard`

---

## Context

The pre-rewrite guardrail library (spec 001, `python/arc-guardrails/`) used abstract base classes (ABC) for all extension points. Operators extending the system had to:

1. Import the ABC from the SDK
2. Subclass it
3. Register the subclass with a decorator or config entry
4. Accept that any future change to the ABC's method signatures required a version bump and operator code changes

This created tight coupling: the SDK's internal hierarchy leaked into operator code. A breaking change to `BaseInspector` forced every downstream implementation to update.

The rewrite coincided with Python 3.11+ becoming the baseline, giving access to mature PEP 544 `Protocol` support across all target environments.

---

## Decision

**All extension seams in `arc-guard-core` are defined as PEP 544 structural typing `Protocol` classes, not ABCs.**

```python
# In arc-guard-core — what operators implement against:
class Inspector(Protocol):
    def inspect(self, guard_input: GuardInput) -> list[Finding]: ...

# Operator implementation — no import of Inspector required:
class MyCustomInspector:
    def inspect(self, guard_input: GuardInput) -> list[Finding]:
        ...
```

The SDK never imports the operator's class. The operator's class never imports the SDK's Protocol. They are structurally compatible if and only if the method signatures match.

`@runtime_checkable` is applied selectively (e.g., `LifecycleSink`) to allow `isinstance()` checks at pipeline construction time without forcing the check into hot paths.

---

## Alternatives Considered

| Alternative                 | Reason rejected                                                            |
| --------------------------- | -------------------------------------------------------------------------- |
| ABC inheritance             | Tight coupling; ABC changes force downstream updates; import chain grows   |
| Callable/function-based     | Loses IDE type-checking; no way to express multi-method contracts cleanly  |
| Pydantic models as adapters | Too heavy for the core; adds pydantic dependency to the extension contract |
| Registration decorators     | Hidden side effects at import time; breaks air-gapped deployments          |

---

## Consequences

**Positive:**

- Operator code has zero SDK imports for implementing extensions — the SDK cannot break operator implementations by renaming internal base classes
- `mypy --strict` catches signature mismatches at type-check time, not runtime
- `@runtime_checkable` + `isinstance()` at pipeline construction provides a clear error if an operator passes a non-conforming class
- New methods can be added to a Protocol as optional (via `typing.Protocol` subclassing) without breaking existing implementations
- The install-closure test (`packages/core/tests/integration/test_install_closure.py`) verifies that `arc-guard-core` has zero non-stdlib runtime dependencies — enforced structurally, not by convention

**Negative / Trade-offs:**

- No shared implementation (mixins) — operators who want default behavior must copy it or import concrete helper classes from `arc-guard`
- Protocol conformance is checked structurally (duck typing) — a class with the right method signature but wrong semantics passes the check. Conformance tests (`packages/pip/tests/middleware/test_semantic_conformance.py`, `test_jailbreak_ml_conformance.py`) mitigate this at the behavioral level
- `@runtime_checkable` only checks for method presence, not signature — `isinstance(obj, Inspector)` passes even if `inspect` has the wrong argument count. This is a known limitation of PEP 544 at runtime.
