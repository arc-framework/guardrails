# ADR: Canvas Source of Truth and Sync Policy

**Status:** Accepted  
**Date:** 2026-05-09  
**Applies to:** All `.canvas` files under `docs/canvases/` and their counterparts in `apps/guardrail-flow/canvases/`

---

## Context

The GuardRailFlow SPA (`apps/guardrail-flow/`) statically imports canvas data at build time via `canvas-registry.ts`. Each canvas is registered as a `.canvas.json` file in `apps/guardrail-flow/canvases/`. These files are Vite build-time imports — the app has no runtime filesystem access.

The canvas designs are also maintained as Obsidian-compatible `.canvas` files in `docs/canvases/`. Obsidian uses the same JSON schema as the app's `.canvas.json` format, but with a different extension. This created two co-existing copies of each canvas that diverged over time as the system evolved — the app copy updated for display, the docs copy updated for documentation.

---

## Decision

**`docs/canvases/` is the single source of truth for all canvas content. The app's `apps/guardrail-flow/canvases/` directory is a derived copy, never edited directly.**

Sync is performed by `scripts/sync-canvases.sh`, which:

1. Copies each `docs/canvases/*.canvas` → `apps/guardrail-flow/canvases/*.canvas.json`
2. Validates JSON parse-ability before copying (rejects malformed source)
3. Skips `old-flow.canvas` (excluded from the app registry)
4. Prints a per-file status line for auditability

The sync script is run manually after canvas edits; it is not a build step or a git hook, to avoid slowing the build or blocking commits on canvas updates.

---

## Alternatives Considered

| Alternative                                  | Reason rejected                                                                                                         |
| -------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| App copy as source of truth; docs as derived | Breaks Obsidian workflow; docs/ would require a reverse-sync step that's harder to audit                                |
| Single file with dual extension (symlink)    | Git does not track symlinks portably across macOS/Linux/Windows; Vite requires the `.json` extension for static imports |
| Runtime fetch from docs/ at app startup      | GuardRailFlow is a static SPA with no server-side filesystem; Vite builds at compile time                               |
| Keep both in sync manually                   | What created the divergence problem in the first place                                                                  |

---

## Consequences

**Positive:**

- Obsidian users edit the canonical `.canvas` file; no mental model overhead about which copy is real
- `scripts/sync-canvases.sh` makes the relationship explicit and auditable
- JSON validation in the script catches malformed edits before they reach the app
- Archive step (run once at 2026-05-09 before the canvas refresh) preserves both pre-change copies under `docs/canvases/_archive/`

**Negative / Trade-offs:**

- Developers must remember to run the sync script after canvas edits; there is no automated enforcement
- The app will be out of date between an edit in `docs/canvases/` and the next sync run — this is acceptable given the canvas files are documentation assets, not application code
- `old-flow.canvas` exists in `docs/canvases/` but is excluded from the app; its exclusion must be maintained manually in `canvas-registry.ts` if the sync script changes

---

## References

- `scripts/sync-canvases.sh`
- `apps/guardrail-flow/src/lib/canvas/canvas-registry.ts`
- `docs/canvases/README.md`
- `docs/canvases/_archive/2026-05-09/` — pre-refresh archive
