# ADR: SQLite as the Lifecycle Sink Storage Backend

**Status:** Accepted  
**Date:** 2026-04-12 (lifecycle event substrate addition)  
**Applies to:** `SqliteLifecycleSink` in `packages/pip/src/arc_guard/observability/`

---

## Context

The `LifecycleSink` Protocol emits up to 29 typed events per guard request. Operators need at least two capabilities built on top of those events:

1. **Replay** — retrieve the full ordered event stream for a past request (`GET /lifecycle/{rid}`)
2. **Dashboard queries** — list recent requests, filter by action/risk, retrieve decision records and debug entries

These needs require durable, queryable storage. The implementation must run without any external services — `arc-guard` targets air-gapped, single-tenant enterprise deployments where adding a required database service creates operational friction.

---

## Decision

**`SqliteLifecycleSink` uses SQLite (via Python's stdlib `sqlite3`) as the durable store for lifecycle events and derived projections.**

Schema version 2 ships four tables:

| Table               | Primary Key          | Contents                                                                        |
| ------------------- | -------------------- | ------------------------------------------------------------------------------- |
| `lifecycle_events`  | `(rid, seq)`         | Full JSON-serialized `LifecycleEvent` per emission                              |
| `request_summaries` | `rid`                | Writer-side projection: action, risk_band, finding_count, duration_ms           |
| `decision_records`  | `(rid, decision_id)` | JSON1 payload; one row per `PolicyDecision` emitted                             |
| `debug_entries`     | `(rid, seq)`         | Structured log lines captured via `logging.Handler` tap on the `rid` contextvar |

WAL mode is enabled at connection open time. Retention is enforced by a background task that GC's all four tables in lockstep.

---

## Alternatives Considered

| Alternative                                  | Reason rejected                                                                                                          |
| -------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| Ring-buffer only (`RingBufferLifecycleSink`) | In-memory; lost on restart. Suitable for ephemeral dev use, not durable replay                                           |
| External TSDB (InfluxDB, TimescaleDB)        | Requires a running external service; breaks air-gapped and single-binary deployments                                     |
| Redis / NATS persistence                     | Same operational dependency problem; adds a required network service                                                     |
| PostgreSQL / MySQL                           | Heavyweight; requires a daemon; violates the zero-external-runtime-deps invariant for the self-contained deployment mode |
| File-per-request (JSONL blobs)               | No relational query capability; no efficient `GET /requests` filtering without full scan                                 |

---

## Consequences

**Positive:**

- Zero runtime dependencies beyond Python's stdlib — `sqlite3` ships with CPython
- WAL mode allows concurrent reads alongside the single writer without blocking
- JSON1 extension (bundled with SQLite ≥ 3.38) enables structured queries on event payloads without a separate serialization layer
- Retention task is a single `DELETE WHERE created_at < cutoff` across all four tables — no tombstoning complexity
- Single-file database makes backup, migration, and testing trivial (copy the file; use `:memory:` in tests)

**Negative / Trade-offs:**

- Single-writer limitation: SQLite's WAL mode allows one concurrent writer. High-throughput environments with many simultaneous guard requests may see lock contention; this is acceptable for single-tenant deployments but would require a different backend for multi-instance horizontal scaling
- No built-in replication: the SQLite file is local to the process; HA requires operator-level volume replication
- `isinstance` at pipeline construction validates `SqliteLifecycleSink` against `LifecycleSink` Protocol — method-presence only, not signature. Behavioral conformance tests cover this gap
- Schema migrations are forward-only (no rollback); the version field in `lifecycle_metadata` table guards against running an old binary against a new schema

---

## References

- `packages/pip/src/arc_guard/observability/sqlite_lifecycle_sink.py`
- `packages/pip/src/arc_guard/observability/ring_buffer_lifecycle_sink.py`
- `packages/pip/src/arc_guard/observability/composite_lifecycle_sink.py`
- `packages/core/src/arc_guard_core/lifecycle/sink.py` — `LifecycleSink` Protocol
