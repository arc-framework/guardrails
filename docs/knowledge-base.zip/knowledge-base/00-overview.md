# arc-guardrails — Overview

## What it is

`arc-guardrails` is a **protocol-driven, in-process privacy enforcement pipeline** for enterprise AI systems. It sits between application callers and external LLM APIs, intercepting both directions of the conversation to detect, transform, and audit sensitive data — without introducing a network hop.

The core thesis (BITS Pilani CCZG628T, 2024MT03053): enterprises adopting Model-as-a-Service platforms are forced to transmit raw business context — PII, PCI, PHI — to third-party inference endpoints. Contractual data agreements don't provide technical guarantees. This system provides that guarantee at the code level.

## The problem it solves

| Problem                                   | How arc-guardrails addresses it                                                                                                  |
| ----------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| PII/PCI leakage to external LLMs          | Presidio NER + regex inspectors detect and redact/pseudonymize before the prompt leaves                                          |
| Prompt injection & jailbreak attacks      | Rule-based jailbreak detector (`packages/pip/src/arc_guard/jailbreak/detector.py`) + deception tracking                          |
| SQL/shell injection in LLM-generated code | Dedicated code injection inspectors (`packages/pip/src/arc_guard/inspectors/code_injection/`)                                    |
| Answer drift after sanitization           | Semantic fidelity scorer verifies output aligns with captured intent before rehydration                                          |
| Opaque guardrail decisions                | 29-event lifecycle taxonomy (`packages/core/src/arc_guard_core/lifecycle/events.py`) gives operators per-request forensic traces |
| Vendor lock-in on guardrail extensions    | PEP 544 structural protocols — any conforming class is accepted without inheritance                                              |

## Three-package architecture

The import direction is strictly one-way:

```
arc_guard_service  →  arc_guard  →  arc_guard_core
```

| Package          | Distribution        | Responsibility                                                                                                                                        |
| ---------------- | ------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| `packages/core/` | `arc-guard-core`    | Zero-dependency contract layer: typed models, Protocols, stage descriptors, exception hierarchy, lifecycle event taxonomy, placeholder registry       |
| `packages/pip/`  | `arc-guard`         | Batteries-included runtime: GuardPipeline orchestration, all concrete inspectors and strategies, observability sinks, rehydration, evaluation harness |
| `packages/api/`  | `arc-guard-service` | FastAPI deployment surface: HTTP transport, dashboard routes, CORS, lifecycle sink wiring — no guardrail logic lives here                             |

`core` has **zero non-stdlib runtime dependencies**. Heavy extras (`[semantic]`, `[jailbreak-ml]`) are isolated in `pip` behind optional install groups.

## Core design principles

1. **Protocol-first extension** — every seam (`Inspector`, `ActionStrategy`, `LifecycleSink`, `Reporter`, `FlagProvider`, `IntentEncoder`, `FidelityScorer`, `RehydrationVerifier`, `JailbreakDetector`, `ConversationTurnInspector`) is a PEP 544 `Protocol`. Third parties extend without inheriting from SDK base classes.

2. **Fail-safe posture** — each failure class has a documented posture: fail-open where a broken detector is safer than blocking all traffic; fail-closed where a broken transformation cannot be trusted. Lifecycle sinks always fail-open (a dropped event never affects the request outcome).

3. **Payload-safe telemetry** — raw PII strings never appear in logs, metrics, spans, or audit records under default settings. The `lifecycle_capture_payloads` and `lifecycle_capture_raw_input` flags are opt-in and security-soak-tested.

4. **Additive evolution** — every spec from 002 to 013 has been purely additive. The 12-stage pipeline shape and the contract types are stable; new stages, events, and dashboard routes extended without deprecations.

## Current state (as of 2026-05-09)

| Spec | What it delivered                                                                   |
| ---- | ----------------------------------------------------------------------------------- |
| 001  | Baseline pre-rewrite library (retired)                                              |
| 002  | Package split, stable contracts, migration path                                     |
| 003  | Typed-placeholder sanitization, policy routing, risk bands                          |
| 004  | Stage instrumentation, failure posture, OTEL adapter                                |
| 005  | Intent capture, fidelity scoring, verified rehydration                              |
| 006  | Jailbreak categorization, multi-turn deception tracking, evaluation harness         |
| 007  | FastAPI service scaffold, OpenAI-compatible transport                               |
| 008  | _(scope retired)_                                                                   |
| 009  | Pre-rewrite tree retirement                                                         |
| 010  | Lifecycle sink: 28 event types, ring-buffer + SQLite + composite sinks, SSE feed    |
| 011  | StrategySelector + ContentPolicy protocols, SQL/shell/template injection inspectors |
| 012  | Dashboard backend data plane: 4 read routes, 3 SQLite tables, CORS allow-list       |
| 013  | GuardRailFlow SPA — Vite/React/TypeScript operator dashboard                        |
| 015  | _(in progress)_                                                                     |
